<?php 

//this file includes all banned ip ranges, currently 23.9k custom ip bot ranges. realtime updated list as of 20/08/22.
$bannedIP = array(
"216.18.228.*",
"cc.106.213.*");

?>