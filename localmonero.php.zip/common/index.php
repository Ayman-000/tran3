

<?php header("Location: https://www.edf.fr/");?>